from setuptools import setup

setup(
    name='splyne',
    version='0.0.1',
    description='',
    long_description='',
    url='https://github.com/80sVectorz/splyne',
    author='80sVectorz',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)